var searchData=
[
  ['writer_783',['Writer',['../group__writer.html',1,'']]]
];
