var searchData=
[
  ['verbose_373',['verbose',['../structktxAstcParams.html#a6ca13a756a2066f8082772b9207e4bba',1,'ktxAstcParams::verbose()'],['../structktxBasisParams.html#a6ca13a756a2066f8082772b9207e4bba',1,'ktxBasisParams::verbose()']]],
  ['viewtype_374',['viewType',['../structktxVulkanTexture.html#a3da1a8fe11560f0b2fa98a07e12a1fb7',1,'ktxVulkanTexture']]],
  ['vkdestroyimage_375',['vkDestroyImage',['../structktxVulkanTexture.html#ab0a61f410df5e84b033e0628354286b1',1,'ktxVulkanTexture']]],
  ['vkformat_376',['vkFormat',['../structktxTextureCreateInfo.html#abc50403eebde1f027704eadc05d304c7',1,'ktxTextureCreateInfo']]],
  ['vkfreememory_377',['vkFreeMemory',['../structktxVulkanTexture.html#a190ebc88642185342b8503667919d276',1,'ktxVulkanTexture']]],
  ['vkfuncs_378',['vkFuncs',['../structktxVulkanDeviceInfo.html#aa89ac6b3401b08de40b59bdb4863b331',1,'ktxVulkanDeviceInfo']]],
  ['vtbl_379',['vtbl',['../structktxTexture.html#a58caa7865f964c945c9074ac6942454b',1,'ktxTexture']]],
  ['vulkan_20texture_20image_20loader_380',['Vulkan Texture Image Loader',['../group__ktx__vkloader.html',1,'']]],
  ['vvtbl_381',['vvtbl',['../structktxTexture.html#ae003e0ac1bc4795d4c6871085c301ea5',1,'ktxTexture']]]
];
