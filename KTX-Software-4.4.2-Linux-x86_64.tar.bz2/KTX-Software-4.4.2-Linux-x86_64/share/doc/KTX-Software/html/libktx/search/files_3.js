var searchData=
[
  ['strings_2ec_406',['strings.c',['../strings_8c.html',1,'']]]
];
