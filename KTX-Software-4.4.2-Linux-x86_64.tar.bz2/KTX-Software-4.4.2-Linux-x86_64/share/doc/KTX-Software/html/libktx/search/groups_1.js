var searchData=
[
  ['reader_781',['Reader',['../group__reader.html',1,'']]]
];
