var searchData=
[
  ['file_557',['file',['../structktxStream.html#a702945180aa732857b380a007a7e2a21',1,'ktxStream']]],
  ['freememfuncptr_558',['freeMemFuncPtr',['../structktxVulkanTexture__subAllocatorCallbacks.html#a729da8478ea87a7f3683b3c010f8cffc',1,'ktxVulkanTexture_subAllocatorCallbacks']]]
];
