var searchData=
[
  ['endpointrdothreshold_556',['endpointRDOThreshold',['../structktxBasisParams.html#aafccbc4e43845f62cf500d4792c7cf6a',1,'ktxBasisParams']]]
];
