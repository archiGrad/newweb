var searchData=
[
  ['noendpointrdo_331',['noEndpointRDO',['../structktxBasisParams.html#a24b0d409b2fbd536216196ca4e27358f',1,'ktxBasisParams']]],
  ['normalmap_332',['normalMap',['../structktxAstcParams.html#a59af70a939f66dce9749174c12cc3725',1,'ktxAstcParams::normalMap()'],['../structktxBasisParams.html#a59af70a939f66dce9749174c12cc3725',1,'ktxBasisParams::normalMap()']]],
  ['noselectorrdo_333',['noSelectorRDO',['../structktxBasisParams.html#a740b64ff37292977ab3cf04d3fb3cd6b',1,'ktxBasisParams']]],
  ['nosse_334',['noSSE',['../structktxBasisParams.html#a0024310d24bafd33ab41de3bd7dd6887',1,'ktxBasisParams']]],
  ['numdimensions_335',['numDimensions',['../structktxTexture.html#ae4378ab23f88acb257e6b4c1d8f64bb8',1,'ktxTexture::numDimensions()'],['../structktxTextureCreateInfo.html#a3c48573960eb90b1e38cc70457d2cda1',1,'ktxTextureCreateInfo::numDimensions()']]],
  ['numfaces_336',['numFaces',['../structktxTexture.html#acc36239d64c8e0562a7a14ccd140af70',1,'ktxTexture::numFaces()'],['../structktxTextureCreateInfo.html#a3a4bc2fa2e41bcec0bdb265505af0068',1,'ktxTextureCreateInfo::numFaces()']]],
  ['numlayers_337',['numLayers',['../structktxTextureCreateInfo.html#ae1412e2bd82ef1baa7cb1479735d9c86',1,'ktxTextureCreateInfo']]],
  ['numlevels_338',['numLevels',['../structktxTexture.html#aad80dfe68bfa0c1ddcc127c4c6e1dda8',1,'ktxTexture::numLevels()'],['../structktxTextureCreateInfo.html#a782126a62c27ee8660a14565b906694c',1,'ktxTextureCreateInfo::numLevels()']]]
];
